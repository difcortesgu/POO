package Facturas;

import java.util.Scanner;

public class Recibos {

    private int nserie;
    private Item[]producto;
    private Fecha fecha;
    private Cliente cliente;

    public Recibos(int nserie, Item[] producto, Fecha fecha,Cliente cliente) {
        this.nserie = nserie;
        this.producto = producto;
        this.fecha = fecha;
        this.cliente=cliente;
    }

    public int getNserie() {
        return nserie;
    }

    public void setNserie(int nserie) {
        this.nserie = nserie;
    }

    public String getProductoname(int i) {
        return producto[i].getNombre();
    }
    public double getproductoprecio(int i){
        return producto[i].getPrecio();
    }
    public double getproductocant(int i){
        return producto[i].getCantidad();
    }

    public void setProducto(Item[] producto) {
        this.producto = producto;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public void setFecha(Fecha fecha) {
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public double getsubtotal(){
       
        return 0;
    }    
    
    public double gettotal(){
       
        return 0;
    }
    
    public Item getproducto(){
       
        return null;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Item []i1 = new Item[10];
        Fecha f1 = new Fecha(21,02,2017);
        System.out.println("ingrese el nombre del cliente\n");
        String name= in.nextLine();
        System.out.println("ingrese el NIT\n");
        long nit=in.nextLong();
        System.out.println("ingrese la dirección\n");
        String dir =in.nextLine();
       System.out.println("ingrese el tipo de pago\n");
        String pago =in.nextLine();
        Cliente c1 = new Cliente(name,nit,dir,pago);
        boolean ingresar=true;
        int i=0;
        String []nombre = new String[10];
        double []precio=new double[10];
        double []cantidad=new double[10];
        do {
            System.out.println("ingrese el producto numero "+(i+1)+"\n");
            nombre[i]= in.nextLine();
            System.out.println("ingrese el precio\n");
            precio[i]= in.nextDouble();
            System.out.println("ingrese la cantidad\n");
            cantidad[i]=in.nextDouble();
            i1[i]= new Item(nombre[i],precio[i],cantidad[i]);
            i++;
            System.out.println("¿desea ingresar otro producto?(si/no)");
            String continuar=in.nextLine();
            if(continuar.equalsIgnoreCase("no")){
                ingresar=false;
            }
        }while((i<10)||(ingresar=true));
        Recibos recibo = new Recibos(in.nextInt(),i1,f1,c1);
        i=0;
        do {
            System.out.println(recibo.getProductoname(i)+" "+recibo.getproductocant(i)+" "+recibo.getproductoprecio(i));
            i++;
        }while(i<10);

    }
}
