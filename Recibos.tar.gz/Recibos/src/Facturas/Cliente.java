package Facturas;

public class Cliente {
    
    private String nombre;
    private long  nit;
    private String direccion ;
    private String pago;

    public Cliente(String nombre, long nit, String direccion, String pago) {
        this.nombre = nombre;
        this.nit = nit;
        this.direccion = direccion;
        this.pago = pago;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public long getNit() {
        return nit;
    }

    public void setNit(long nit) {
        this.nit = nit;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getPago() {
        return pago;
    }

    public void setPago(String pago) {
        this.pago = pago;
    }
    
    
    
}
