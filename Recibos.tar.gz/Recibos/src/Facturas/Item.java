package Facturas;

public class Item {
    
    private String nombre;
    private double Precio;
    private double cantidad;

    public Item(String nombre, double Precio, double cantidad) {
        this.nombre = nombre;
        this.Precio = Precio;
        this.cantidad = cantidad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return Precio;
    }

    public void setPrecio(double Precio) {
        this.Precio = Precio;
    }

    public double getCantidad() {
        return cantidad;
    }

    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }
    
    
    
}
