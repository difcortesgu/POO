
package Ejercicio6;

import becker.robots.*;
import java.util.Collection;

public class Main {
    
    public static void main (String[] args){
        
        City bogota = new City();
        Columna[] col = new Columna[10];
        col[0] = new Columna(1, false, true);
        col[1] = new Columna(2, false, false);
        col[2] = new Columna(3, false, true);
        col[3] = new Columna(4, false, false);
        col[4] = new Columna(5, false, true);
        col[5] = new Columna(6, false, false);
        col[6] = new Columna(7, false, true);
        col[7] = new Columna(7, false, false);
        col[8] = new Columna(7, false, true);
        col[9] = new Columna(0, false, false);
        Oganizador carlos = new Oganizador(bogota, 6, 1, Direction.EAST, 5, col);
        
        carlos.Ordenar();
    }
    
}
