
package Ejercicio6;

//import becker.robots.*;

public class Columna {
    
    int numCosas;
    boolean arriba;
    boolean caja;

    public Columna(int numCosas, boolean arriba, boolean caja) {  
        this.numCosas = numCosas;
        this.arriba = arriba;
        this.caja = caja;
    }

    public int getNumCosas() {
        return numCosas;
    }

    public void setNumCosas(int numCosas) {
        this.numCosas = numCosas;
    }

    public boolean isArriba() {
        return arriba;
    }

    public void setArriba(boolean arriba) {
        this.arriba = arriba;
    }

    public boolean isCaja() {
        return caja;
    }

    public void setCaja(boolean caja) {
        this.caja = caja;
    }
        
}
