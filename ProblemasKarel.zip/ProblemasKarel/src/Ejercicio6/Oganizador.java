
package Ejercicio6;

import becker.robots.*;

public class Oganizador extends Robot {
    
    int numColumnas;
    Columna[] columna = new Columna[10];

    public Oganizador(City city, int i, int i1, Direction drctn, int numColumnas, Columna[] columnas) {
        super(city, i, i1, drctn, 100);
        this.numColumnas = numColumnas;
        System.arraycopy(columnas, 0, columna, 0, this.numColumnas);
    }

    public int getNumColumnas() {
        return numColumnas;
    }

    public void setNumColumnas(int numColumnas) {
        this.numColumnas = numColumnas;
    }

    public Columna[] getColumna() {
        return columna;
    }

    public void setColumna(Columna[] columna) {
        this.columna = columna;
    }
    
    public void turnRight (){
        for(int i = 0; i<3; i++) this.turnLeft();
    }
    
    private void PonerBorde (Columna col){
        for(int i = 0; i<10; i++){
            this.move();
        }
        for(int j = 0; j<2; j++) this.turnLeft();
        for(int j = 0; j<col.getNumCosas(); j++){            
            this.putThing();
            if(j<col.getNumCosas()-1) this.move();
        }
        for(int k = 0; k<(10-col.getNumCosas()); k++){
            this.move();
        }
    }
    
    private void PonerLinea (Columna col){
        for(int i = 0; i<col.getNumCosas(); i++){           
            this.putThing();
            if(i<col.getNumCosas()-1) this.move();
        }
        for(int j = 0; j<2; j++) this.turnLeft();
        for(int k = 0; k<col.getNumCosas()-1; k++){
            this.move();
        }
    }
    
    private void dibujarColumna (Columna col) {        
        if(col.isArriba()){
            this.PonerBorde(col);
        }else{
            this.PonerLinea(col);
        }
    }
    
    private void CajaoTallos (Columna col){
        if(col.isCaja()){
            this.turnLeft();
            this.dibujarColumna(col);
            this.turnLeft();
        } else {
            this.turnRight();
            this.dibujarColumna(col);
            this.turnRight();
        }
        this.move();
    }
    
    public void Ordenar (){
        for(int i = 0; i<this.numColumnas; i++){
            this.CajaoTallos(this.columna[i]);
        }
    }
    
}
