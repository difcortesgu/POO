
package triangulo;

public class Triangulo {

    private double p;
    private double a;
    private Lado l1;
    private Lado l2;
    private Lado l3;
    private Color fondo;

    public Triangulo(Lado l1, Lado l2, Lado l3, Color fondo) {
        this.l1 = l1;
        this.l2 = l2;
        this.l3 = l3;
        this.fondo = fondo;
        p=this.l1.getl()+this.l2.getl()+this.l3.getl();
        a=Math.sqrt(p/2*((p/2)-l1.getl())*((p/2)-l2.getl())*((p/2)-l3.getl()));
    }

    public Lado getL1() {
        return l1;
    }

    public void setL1(Lado l1) {
        this.l1 = l1;
    }

    public Lado getL2() {
        return l2;
    }

    public void setL2(Lado l2) {
        this.l2 = l2;
    }

    public Lado getL3() {
        return l3;
    }

    public void setL3(Lado l3) {
        this.l3 = l3;
    }

    public Color getFondo() {
        return fondo;
    }

    public void setFondo(Color fondo) {
        this.fondo = fondo;
    }
    
    public double getp(){
        return p;
    }
    
    public double geta(){
        return a;
    }
    
    public static void main(String[] args) {
        
        Color []cl=new Color[3];
        cl[0]=new Color(0,0,0);
        cl[1]=new Color(0,0,0);
        cl[2]=new Color(0,0,0);
        Color fondo= new Color(0,0,0);
        Punto []p=new Punto[3];
        p[0] = new Punto(0,0);
        p[1] = new Punto(4,3);
        p[2] = new Punto(4,0);
        Lado []l=new Lado[3];
        l[0]=new Lado(p[0],p[1],cl[0]);
        l[1]=new Lado(p[1],p[2],cl[1]);
        l[2]=new Lado(p[2],p[0],cl[2]);
        Triangulo tr1=new Triangulo(l[0],l[1],l[2],fondo);
        System.out.println(tr1.geta());
        System.out.println(tr1.getp());
    }
    
}
