
package triangulo;

public class Lado {
        
    private Punto p1;
    private Punto p2;
    private double l;
    private Color c;

    public Lado(Punto p1, Punto p2,Color c) {
        this.c=c;
        this.p1 = p1;
        this.p2 = p2;
        this.l=Math.sqrt(Math.pow(p1.getX()-p2.getX(),2)+Math.pow(p1.getY()-p2.getY(), 2));
    }

    public Punto getP1() {
        return p1;
    }

    public void setP1(Punto p1) {
        this.p1 = p1;
    }

    public Punto getP2() {
        return p2;
    }

    public void setP2(Punto p2) {
        this.p2 = p2;
    }

    public Color getC() {
        return c;
    }

    public void setC(Color c) {
        this.c = c;
    }
    
    public double getl(){
        return this.l;
    }
    
    
}
